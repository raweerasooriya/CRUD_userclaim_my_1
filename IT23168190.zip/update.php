<?php 
    require'config.php';

    $ID = $_POST["ID"];
    $first_name = $_POST["first_name"];
    $last_name = $_POST["last_name"];
    $userId = $_POST["userId"];
    $gender = $_POST["gender"];
    $address = $_POST["address"];
    $phone_number = $_POST["phone_number"];
    $email = $_POST["email"];
    $amount = $_POST["amount"];
    $typesClaims = $_POST["typesClaims"];

    if(empty($first_name) || empty($last_name) || empty($userId)|| empty($gender)|| empty($address)|| empty($phone_number)|| empty($email)|| empty($amount)|| empty($typesClaims)){
        echo 'Please fill out all fields.';
    }
    else{
        $sql="UPDATE `claim` SET `first_name`='$first_name',`last_name`='$last_name',`userId`='$userId',`gender`='$gender',`address`='$address',`phone_number`='$phone_number',`email`='$email',`amount`='$amount',`typesClaims`='$typesClaims' WHERE Id";
    
        if($con->query($sql)) {
        echo"Updated";
        }
        else{
            echo "Not updated";
        }
    
    }
?>