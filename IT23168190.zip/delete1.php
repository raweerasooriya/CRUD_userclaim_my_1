<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post" action="delete.php">
        Claim ID<input type="text" name="Id"><br>
        <input type="submit" value="Delete">
    </form>
</body>
</html>