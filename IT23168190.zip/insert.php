<?php

    require 'config.php';

    $first_name = $_POST["first_name"];
    $last_name = $_POST["last_name"];
    $userId = $_POST["userId"];
    $gender = $_POST["gender"];
    $address = $_POST["address"];
    $phone_number = $_POST["phone_number"];
    $email = $_POST["email"];
    $amount = $_POST["amount"];
    $typesClaims = $_POST["typesClaims"];

    $sql="INSERT INTO `claim`(`Id`, `first_name`, `last_name`, `userId`, `gender`, `address`, `phone_number`, `email`, `amount`, `typesClaims`) 
    VALUES (NULL,'$first_name','$last_name', '$userId','$gender','$address','$phone_number','$email','$amount','$typesClaims')";

    if($con->query($sql)){
        echo "Insert Successful";
    }
    else{
        echo "Error".$con->error;
    }

    $con->close();

?>