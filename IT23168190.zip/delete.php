<?php  

require'config.php';

$ID=$_POST["Id"];

$sql="DELETE FROM `claim`WHERE Id='$ID'";

if($con->query($sql)){

    echo "Deleted";
}
else{
    echo "Not Success";
}
?>